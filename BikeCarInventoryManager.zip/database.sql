-- SQL file to create and populate the vehicles table
CREATE TABLE vehicles (id SERIAL PRIMARY KEY, name TEXT, brand TEXT, price INTEGER, year INTEGER, image TEXT);